<?php include("static/header.php"); ?>

<div class="container">
    <div class="about col-sm-4 col-sm-offset-4">
        <h1>About us</h1>
        <p>
            Created by Alex Nguyen
        <br>
            Contact: <a href="mailto:nguyalex@oregonstate.edu">nguyalex@oregonstate.edu</a>
        </p>
    </div>
</div>
<?php include("static/footer.php"); ?>
