<?php
    $DB_HOST = "oniddb.cws.oregonstate.edu";
    $DB_NAME = "nguyalex-db";
    $DB_USER = "nguyalex-db";
    $DB_PASSWORD = "sf4PChMUktJ2TsEf";
?>
