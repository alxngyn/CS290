                </div><!-- Content div closer-->
                <br>
                <div class="footer">
                    <p>Created by Alex Nguyen CS290 Fall 2015</p>
                </div>
            </div> <!-- Wrapper div closer-->
    </body>
</html>
